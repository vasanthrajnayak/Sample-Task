<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "item_master".
 *
 * @property int $id
 * @property string $name
 * @property string $description
 * @property double $price
 * @property int $status
 */
class ItemMaster extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'item_master';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name', 'description', 'price', 'status'], 'required'],
            [['price'], 'number'],
            [['status'], 'integer'],
            [['name', 'description'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'description' => 'Description',
            'price' => 'Price',
            'status' => 'Status',
        ];
    }
}
